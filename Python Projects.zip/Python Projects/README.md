# python-mini-projects
A collection of Python mini-projects showcasing beginner to intermediate concepts, including a Drink Water Reminder App, News App using APIs, Simple Calculator, AI-powered Virtual Assistant, PDF Merger, and “Who Wants to Be a Millionaire” quiz game.
